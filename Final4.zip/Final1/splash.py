from panda3d.core import *
from direct.showbase.ShowBase import ShowBase
from direct.interval.IntervalGlobal import *

#import display

loadPrcFileData('', 'win-size 1200 800')

class myDemo(ShowBase):
    def __init__(self):

        ShowBase.__init__(self)

        self.menuRotate=0
        self.getHelp=False
        self.inspiration=False
        self.enter=0

        self.loadBackground()

        self.title=loader.loadModel("models2/splashTitle.egg")
        self.title.reparentTo(render)
        self.title.setPos(0,0,0)
        self.title.setHpr(0,0,0)
        rotation1=self.title.hprInterval(5,Point3(45,0,0))
        rotation2=self.title.hprInterval(10,Point3(-45,0,0))
        rotation3=self.title.hprInterval(5,Point3(0,0,0))
        rotation=Sequence(rotation1,rotation2,rotation3)
        rotation.loop()

        self.E8=loader.loadModel("models2/E8.egg")
        self.E8.reparentTo(render)
        self.E8.setScale(2)
        self.E8.setPos(0,5,0)
        E8movement=self.E8.hprInterval(50, LPoint3(0, 0, 360))
        E8movement.loop()

        

        base.cam.setPos(0,-20,0)

        self.accept("enter", self.goMenu)
        self.accept("arrow_right", self.rotateMenu)
        self.accept("tab", self.backToMenu)
        self.accept("space", self.startGame)

    def loadBackground(self):
        #Citation: https://www.panda3d.org/manual/index.php/Lighting
        #add pointlight to each faces to illuminate the whole scene
        plight1=PointLight('plight')
        plight1.setColor(VBase4(0.5,0.5,0.5,0.5))
        plight1NodePath=render.attachNewNode(plight1)
        plight1NodePath.setPos(0,0,500)
        plight1NodePath.setHpr(170,0,0)
        render.setLight(plight1NodePath)

        plight2=PointLight('plight')
        plight2.setColor(VBase4(1, 1, 1, 1))
        plight2NodePath=render.attachNewNode(plight2)
        plight2NodePath.setPos(0,0,-500)
        plight2NodePath.setHpr(170,0,0)
        render.setLight(plight2NodePath)

        plight3=PointLight('plight')
        plight3.setColor(VBase4(0.5,0.5,0.5,0.5))
        plight3NodePath=render.attachNewNode(plight3)
        plight3NodePath.setPos(0, -500, 0)
        plight3NodePath.setHpr(170,0,0)
        render.setLight(plight3NodePath)

        plight4=PointLight('plight')
        plight4.setColor(VBase4(1, 1, 1, 1))
        plight4NodePath=render.attachNewNode(plight4)
        plight4NodePath.setPos(0, 500, 0)
        plight4NodePath.setHpr(170,0,0)
        render.setLight(plight4NodePath)

        plight5=PointLight('plight')
        plight5.setColor(VBase4(0.5,0.5,0.5,0.5))
        plight5NodePath=render.attachNewNode(plight5)
        plight5NodePath.setPos(500,0, 0)
        plight5NodePath.setHpr(170,0,0)
        render.setLight(plight5NodePath)

        plight6=PointLight('plight')
        plight6.setColor(VBase4(1, 1, 1, 1))
        plight6NodePath=render.attachNewNode(plight6)
        plight6NodePath.setPos(-500,0, 0)
        plight6NodePath.setHpr(170,0,0)
        render.setLight(plight6NodePath)

    def goMenu(self):
        self.enter+=1
        zoom1=base.cam.posInterval(0.3,Point3(0,-3,0))
        zoom2=base.cam.posInterval(0.5,Point3(0,5,0))
        zoom3=base.cam.posInterval(0.5,Point3(0,15,0))
        zoom4=base.cam.posInterval(0.5,Point3(0,-20,0))
        if self.enter%2==1:
            self.menu=loader.loadModel("models2/menu1.egg")
            self.menu.reparentTo(render)
            self.menu.setPos(0.75,20,0)
            self.menu.setScale(0.75)
            self.menu2=loader.loadModel("models2/menu2.egg")
            self.menu2.reparentTo(render)
            self.menu2.setPos(-1.125,20,0)
            self.menu2.setScale(0.6)
            menu2movement=self.menu2.hprInterval(10,LPoint3(360,0,0))
            menu2movement.loop()
            self.E8_2=loader.loadModel("models2/E8.egg")
            self.E8_2.reparentTo(render)
            self.E8_2.setScale(2)
            self.E8_2.setPos(0,25,0)
            E8movement=self.E8_2.hprInterval(50, LPoint3(0, 0, 360))
            E8movement.loop()
            zoom=Sequence(zoom1,zoom2,zoom3)
        else: 
            self.menu.removeNode()
            self.menu2.removeNode()
            self.E8_2.removeNode()
            zoom=Sequence(zoom1,zoom4)
        zoom.start()

    def rotateMenu(self):
        self.menuRotate+=1
        rotation=self.menu.hprInterval(3,Point3(0,0,self.menuRotate*90))
        rotation.start()

    def startGame(self):
        if self.menuRotate%4==0:
            display.level=1
            display.base.run()
        elif self.menuRotate%4==2:
            display.level=2
            display.base.run()
        else:
            self.menu2.removeNode()
            mod=self.menuRotate%4
            self.menu3=loader.loadModel("models2/menu3.egg")
            self.menu3.reparentTo(render)
            self.menu3.setPos(-1.125,20,-1)
            self.menu3.setScale(0.5)
            menu3movement=self.menu3.hprInterval(10,LPoint3(360,0,0))
            menu3movement.loop()
            if mod==1:
                self.getHelp=True
            else: 
                self.inspiration=True
                self.inspiration1=loader.loadModel("models2/inspiration1.egg")
                self.inspiration1.reparentTo(render)
                self.inspiration1.setPos(-1.125,20,0.5)     
                        

    def backToMenu(self):
        if self.getHelp or self.inspiration:
            self.menu3.removeNode()
            self.goMenu()

game = myDemo()
base.run()
